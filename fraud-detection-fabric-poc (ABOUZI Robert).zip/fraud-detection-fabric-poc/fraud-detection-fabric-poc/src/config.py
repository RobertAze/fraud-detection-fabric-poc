"""Configuration centrale du projet — toutes les valeurs validées empiriquement."""

# Colonnes avec sentinelle -1 = valeur manquante
SENTINEL_MISSING_COLS = [
    'prev_address_months_count', 'bank_months_count',
    'current_address_months_count', 'session_length_in_minutes',
    'device_distinct_emails_8w'
]

# Colonnes constantes / sans valeur -> à supprimer en Silver
CONSTANT_COLS_TO_DROP = ['device_fraud_count']

# Colonnes catégorielles nominales -> one-hot encoding
CATEGORICAL_COLS = ['payment_type', 'employment_status', 'housing_status', 'device_os', 'source']

# Vélocités à fort drift temporel (PSI > 0.9), retirées du modèle final
DRIFTING_VELOCITY_COLS = ['velocity_6h', 'velocity_24h', 'velocity_4w']

# Split temporel validé (drift du taux de fraude : 1.03% train -> 1.40% test)
TRAIN_MONTHS_MAX = 5
TEST_MONTHS_MIN = 6

# Hyperparamètres LightGBM finaux (tuning Optuna, 30 essais, moyenne 3 seeds)
LGBM_BEST_PARAMS = {
    'num_leaves': 20,
    'max_depth': 9,
    'learning_rate': 0.021380993591973603,
    'min_child_samples': 93,
    'subsample': 0.7164607419665912,
    'colsample_bytree': 0.9336479655855263,
    'n_estimators': 500,
}
SCALE_POS_WEIGHT_MULTIPLIER = 0.9443628962265538  # Optuna a contredit l'heuristique manuelle (*0.3)

# Métrique métier et seuil validé
TARGET_FPR = 0.05
DECISION_THRESHOLD = 0.762091  # FPR réel : 0.0502 sur le test

# Chemins des artefacts de déploiement (contrat produit par le notebook 02)
MODEL_EXPORT_DIR = "/lakehouse/default/Files/model_export"

MLFLOW_EXPERIMENT_NAME = "fraud_detection_ecobank_poc"
