"""Pipeline complet Bronze -> Silver -> Gold -> Entraînement -> Scoring.

Point d'entrée unique, appelable depuis un notebook Fabric ou une activité
Data Factory. Chaque étape est aussi appelable individuellement — c'est ce que
font les notebooks 01, 02 et 03, orchestrés par Pipeline_Orchestration_Fraud.
"""

import mlflow
from src.data.bronze import read_bronze
from src.data.silver import bronze_to_silver
from src.data.gold import silver_to_gold
from src.models.train import temporal_split, prepare_features, train_final_model
from src.models.evaluate import recall_at_fpr, compute_decision_threshold, check_overfitting
from src.models.score import score_batch
from src.config import MLFLOW_EXPERIMENT_NAME, TARGET_FPR


def run_full_pipeline(spark, source_path: str, log_to_mlflow: bool = True,
                      run_scoring: bool = True):
    # --- Données ---
    read_bronze(spark, source_path)
    bronze_to_silver(spark)
    silver_to_gold(spark)

    # --- Entraînement / évaluation ---
    df_gold_pd = spark.read.table("gold_transactions").toPandas()
    train_df, test_df = temporal_split(df_gold_pd)
    X_train, y_train, X_test, y_test, feature_cols = prepare_features(train_df, test_df)

    model = train_final_model(X_train, y_train)

    proba_test = model.predict_proba(X_test)[:, 1]
    recall = recall_at_fpr(y_test, proba_test, TARGET_FPR)
    threshold, achieved_fpr, _ = compute_decision_threshold(y_test, proba_test, TARGET_FPR)
    overfit = check_overfitting(model, X_train, y_train, X_test, y_test, TARGET_FPR)

    print(f"Recall @ {TARGET_FPR*100:.0f}% FPR : {recall:.4f}")
    print(f"Seuil : {threshold:.6f} (FPR atteint : {achieved_fpr:.4f})")
    print(f"Écart surapprentissage : {overfit['overfitting_gap']:.4f}")

    if log_to_mlflow:
        mlflow.set_experiment(MLFLOW_EXPERIMENT_NAME)
        with mlflow.start_run(run_name="pipeline_full_run"):
            mlflow.log_metric("recall_at_5pct_fpr", recall)
            mlflow.log_metric("decision_threshold", threshold)
            mlflow.log_metric("overfitting_gap", overfit['overfitting_gap'])
            mlflow.lightgbm.log_model(model, "model")

    # --- Scoring batch (suppose l'export du notebook 02 présent) ---
    if run_scoring:
        score_batch(spark)

    return model, {'recall': recall, 'threshold': threshold, **overfit}
