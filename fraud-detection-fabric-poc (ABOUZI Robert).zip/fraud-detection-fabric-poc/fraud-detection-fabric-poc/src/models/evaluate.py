"""Métriques — recall@FPR fixé, protocole standard de ce dataset (Feedzai/NeurIPS 2022)."""

import numpy as np
from sklearn.metrics import roc_curve


def recall_at_fpr(y_true, y_proba, target_fpr: float = 0.05):
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    idx = np.searchsorted(fpr, target_fpr)
    return tpr[idx]


def compute_decision_threshold(y_true, y_proba, target_fpr: float = 0.05):
    """Seuil de probabilité exact au FPR cible — indispensable pour l'inférence."""
    fpr, tpr, thresholds = roc_curve(y_true, y_proba)
    idx = np.searchsorted(fpr, target_fpr)
    return thresholds[idx], fpr[idx], tpr[idx]


def check_overfitting(model, X_train, y_train, X_test, y_test, target_fpr: float = 0.05):
    proba_train = model.predict_proba(X_train)[:, 1]
    proba_test = model.predict_proba(X_test)[:, 1]
    recall_train = recall_at_fpr(y_train, proba_train, target_fpr)
    recall_test = recall_at_fpr(y_test, proba_test, target_fpr)
    return {'recall_train': recall_train, 'recall_test': recall_test,
            'overfitting_gap': recall_train - recall_test}
