"""Préparation des features, split temporel, entraînement du modèle final."""

import pandas as pd
import lightgbm as lgb
from src.config import (CATEGORICAL_COLS, DRIFTING_VELOCITY_COLS, TRAIN_MONTHS_MAX,
                        TEST_MONTHS_MIN, LGBM_BEST_PARAMS, SCALE_POS_WEIGHT_MULTIPLIER)


def temporal_split(df_gold_pd: pd.DataFrame):
    """Mois 0-5 train, 6-7 test. Justifié par le drift mesuré (1.03% -> 1.40%)."""
    train_df = df_gold_pd[df_gold_pd['month'] <= TRAIN_MONTHS_MAX].copy()
    test_df = df_gold_pd[df_gold_pd['month'] >= TEST_MONTHS_MIN].copy()
    return train_df, test_df


def prepare_features(train_df: pd.DataFrame, test_df: pd.DataFrame,
                     drop_drifting_velocity: bool = True):
    """One-hot fit sur train uniquement, appliqué au test par reindex (schémas alignés).

    drop_drifting_velocity=True : retire les vélocités brutes (PSI > 0.9) au profit
    du ratio — gain de robustesse validé sur 3 seeds (+0.0074, jamais négatif).
    """
    train, test = train_df.copy(), test_df.copy()
    if drop_drifting_velocity:
        train = train.drop(columns=DRIFTING_VELOCITY_COLS)
        test = test.drop(columns=DRIFTING_VELOCITY_COLS)

    train_enc = pd.get_dummies(train, columns=CATEGORICAL_COLS, drop_first=True)
    test_enc = pd.get_dummies(test, columns=CATEGORICAL_COLS, drop_first=True)
    test_enc = test_enc.reindex(columns=train_enc.columns, fill_value=0)

    feature_cols = [c for c in train_enc.columns if c not in ['fraud_bool', 'month']]
    return (train_enc[feature_cols], train_enc['fraud_bool'],
            test_enc[feature_cols], test_enc['fraud_bool'], feature_cols)


def train_final_model(X_train, y_train):
    """LightGBM avec hyperparamètres Optuna. Nulls natifs préservés (aucune imputation) :
    la gestion native des valeurs manquantes s'est montrée supérieure à la médiane."""
    scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum() * SCALE_POS_WEIGHT_MULTIPLIER

    model = lgb.LGBMClassifier(
        **LGBM_BEST_PARAMS,
        scale_pos_weight=scale_pos_weight,
        random_state=42,
        verbose=-1
    )
    model.fit(X_train, y_train)
    return model
