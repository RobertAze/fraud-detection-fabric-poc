"""Scoring batch — applique le modèle exporté sur la table Gold complète.

Le contrat d'inférence est le dossier model_export/ produit par le notebook 02 :
le modèle sérialisé, le seuil de décision calibré, et l'ORDRE EXACT des colonnes
de features. Reproduire cet ordre est critique : un désalignement ne lève aucune
erreur, il produit des scores silencieusement faux.
"""

import json
import pickle
from datetime import datetime, timezone

import pandas as pd
from src.config import CATEGORICAL_COLS, DRIFTING_VELOCITY_COLS, MODEL_EXPORT_DIR


def load_deployment_artifacts(export_dir: str = MODEL_EXPORT_DIR):
    """Charge le modèle et ses métadonnées (seuil, colonnes) exportés par le notebook 02."""
    with open(f"{export_dir}/lgbm_fraud_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{export_dir}/model_metadata.json", "r") as f:
        metadata = json.load(f)
    return model, metadata


def build_scoring_matrix(df_gold_pd: pd.DataFrame, feature_columns: list) -> pd.DataFrame:
    """Reproduit exactement le préprocessing d'entraînement sur l'ensemble des lignes.

    One-hot puis reindex sur les colonnes figées à l'entraînement : toute modalité
    apparue depuis reste à zéro sur ses dummies (catégorie de référence), toute
    colonne attendue absente est créée à zéro. Le schéma est garanti identique.
    """
    df = df_gold_pd.drop(columns=[c for c in DRIFTING_VELOCITY_COLS if c in df_gold_pd.columns])
    encoded = pd.get_dummies(df, columns=CATEGORICAL_COLS, drop_first=True)
    matrix = encoded.reindex(columns=feature_columns, fill_value=0)
    assert list(matrix.columns) == list(feature_columns), "Désalignement des colonnes de scoring"
    return matrix


def score_batch(spark, gold_table: str = "gold_transactions",
                scored_table: str = "gold_scored_transactions",
                export_dir: str = MODEL_EXPORT_DIR):
    """Score la table Gold complète et écrit la table de restitution pour Power BI.

    La table de sortie conserve les colonnes métier d'origine et ajoute :
    fraud_score (probabilité), is_alert (décision au seuil calibré),
    scored_at et model_threshold (traçabilité de la version de scoring).
    """
    model, metadata = load_deployment_artifacts(export_dir)
    threshold = metadata["decision_threshold"]

    df_gold_pd = spark.read.table(gold_table).toPandas()
    matrix = build_scoring_matrix(df_gold_pd, metadata["feature_columns"])

    df_gold_pd["fraud_score"] = model.predict_proba(matrix)[:, 1]
    df_gold_pd["is_alert"] = (df_gold_pd["fraud_score"] >= threshold).astype(int)
    df_gold_pd["model_threshold"] = threshold
    df_gold_pd["scored_at"] = datetime.now(timezone.utc).isoformat()

    spark.createDataFrame(df_gold_pd).write.format("delta") \
        .mode("overwrite").option("overwriteSchema", "true").saveAsTable(scored_table)

    alert_rate = df_gold_pd["is_alert"].mean()
    print(f"Table scorée écrite : {scored_table} ({len(df_gold_pd):,} lignes)")
    print(f"Taux d'alerte : {alert_rate*100:.2f}% (attendu ~5% par construction du seuil)")
    return alert_rate
