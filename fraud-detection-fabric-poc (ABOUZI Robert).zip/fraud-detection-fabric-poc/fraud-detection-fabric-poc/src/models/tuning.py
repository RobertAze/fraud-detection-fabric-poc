"""Recherche Optuna — moyenne sur plusieurs seeds pour ne pas optimiser du bruit
(l'écart inter-seed ~0.01 est du même ordre que le gain de tuning)."""

import numpy as np
import lightgbm as lgb
import optuna
from src.models.evaluate import recall_at_fpr


def run_optuna_search(X_train, y_train, X_test, y_test, n_trials: int = 30, seeds=(42, 7, 123)):
    scale_pos_weight_base = (y_train == 0).sum() / (y_train == 1).sum()

    def objective(trial):
        params = {
            'num_leaves': trial.suggest_int('num_leaves', 15, 63),
            'max_depth': trial.suggest_int('max_depth', 4, 10),
            'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),
            'min_child_samples': trial.suggest_int('min_child_samples', 20, 100),
            'subsample': trial.suggest_float('subsample', 0.6, 1.0),
            'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
            'scale_pos_weight': trial.suggest_float('scale_pos_weight_mult', 0.1, 1.0) * scale_pos_weight_base,
        }
        recalls = []
        for seed in seeds:
            model = lgb.LGBMClassifier(**params, n_estimators=500, random_state=seed, verbose=-1)
            model.fit(X_train, y_train)
            recalls.append(recall_at_fpr(y_test, model.predict_proba(X_test)[:, 1]))
        return np.mean(recalls)

    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)
    return study
