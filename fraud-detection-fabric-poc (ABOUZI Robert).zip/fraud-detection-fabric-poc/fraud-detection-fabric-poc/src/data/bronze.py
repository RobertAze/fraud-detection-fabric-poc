"""Ingestion Bronze — lecture brute, aucune transformation."""


def read_bronze(spark, source_path: str, table_name: str = "bronze_transactions"):
    """Lit le CSV source et l'écrit tel quel en table Delta Bronze.

    Aucune transformation : le Bronze doit rester une copie fidèle de la source.
    """
    df = spark.read.option("header", True).option("inferSchema", True).csv(source_path)
    df.write.format("delta").mode("overwrite").saveAsTable(table_name)
    print(f"Bronze écrit : {table_name} ({df.count()} lignes)")
    return df
