"""Transformation Silver -> Gold : feature engineering métier, audité (leakage, signal)."""

from pyspark.sql import functions as F


def silver_to_gold(spark, silver_table: str = "silver_transactions",
                   gold_table: str = "gold_transactions"):
    """Features validées :

    - velocity_ratio_24h_4w : ratio d'activité, robuste au drift (les vélocités brutes
      ont un PSI de 0.92 à 2.89 et sont exclues du modèle final).
    - device_email_risk_score : composite (email_is_free + device_distinct_emails_8w) ;
      device_fraud_count exclu car constant.
    - phone_validity_score : somme des validités téléphone.
    - credit_risk_score conservé : corrélation 0.07 avec la cible, pas de leakage.
    """
    df_silver = spark.read.table(silver_table)

    df_gold = (
        df_silver
        .withColumn('velocity_ratio_24h_4w',
            F.when(F.col('velocity_4w') != 0, F.col('velocity_24h') / F.col('velocity_4w')).otherwise(None))
        .withColumn('device_email_risk_score',
            (F.when(F.col('email_is_free') == 1, 1).otherwise(0) +
             F.when(F.col('device_distinct_emails_8w') > 1, 1).otherwise(0)))
        .withColumn('phone_validity_score', F.col('phone_home_valid') + F.col('phone_mobile_valid'))
    )

    df_gold.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(gold_table)
    print(f"Gold écrite : {gold_table}")
    return df_gold
