"""Transformation Bronze -> Silver : sentinelles -1 en null natif, flags informatifs."""

from pyspark.sql import functions as F
from src.config import CONSTANT_COLS_TO_DROP


def bronze_to_silver(spark, bronze_table: str = "bronze_transactions",
                     silver_table: str = "silver_transactions"):
    """Règles validées empiriquement sur ce dataset :

    - prev_address_months_count (71% manquant, fraude x4.6 si absent) :
      colonne supprimée, flag has_prev_address conservé.
    - current_address_months_count (0.4% manquant, signal x3.4 confirmé, z=4.8) :
      flag + null natif, PAS d'imputation.
    - bank_months_count (25% manquant, signal x1.8) : null natif sans flag
      (l'importance du modèle a montré le flag redondant avec la gestion native des null).
    - session_length_in_minutes, device_distinct_emails_8w (<1%, aucun signal) :
      -1 converti en null natif, rien d'autre.
    - device_fraud_count : constante (100% à 0) -> supprimée.
    """
    df = spark.read.table(bronze_table)

    df_silver = (
        df
        .withColumn('has_prev_address', F.when(F.col('prev_address_months_count') == -1, 0).otherwise(1))
        .withColumn('current_address_missing', F.when(F.col('current_address_months_count') == -1, 1).otherwise(0))
        .drop('prev_address_months_count')
        .withColumn('bank_months_count',
            F.when(F.col('bank_months_count') == -1, None).otherwise(F.col('bank_months_count')))
        .withColumn('current_address_months_count',
            F.when(F.col('current_address_months_count') == -1, None).otherwise(F.col('current_address_months_count')))
        .withColumn('session_length_in_minutes',
            F.when(F.col('session_length_in_minutes') == -1, None).otherwise(F.col('session_length_in_minutes')))
        .withColumn('device_distinct_emails_8w',
            F.when(F.col('device_distinct_emails_8w') == -1, None).otherwise(F.col('device_distinct_emails_8w')))
        .drop(*CONSTANT_COLS_TO_DROP)
    )

    df_silver.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(silver_table)
    print(f"Silver écrite : {silver_table}")
    return df_silver
