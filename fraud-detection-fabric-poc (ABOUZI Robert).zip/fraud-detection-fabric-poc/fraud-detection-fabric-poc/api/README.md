---
title: API Detection de Fraude Bancaire
emoji: 🏦
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
pinned: false
---

# API de détection de fraude à l'ouverture de compte

API d'inférence temps réel adossée à un modèle LightGBM entraîné sur le **Bank Account Fraud Suite** (NeurIPS 2022, Feedzai). Complément du pipeline de scoring batch construit sur Microsoft Fabric (architecture médaillon Bronze / Silver / Gold).

**Documentation interactive :** `/docs` (Swagger UI).

## Performance du modèle

| Modèle | Recall @ 5% FPR |
|---|---|
| Régression logistique (baseline) | 0.5066 |
| LightGBM (réglage manuel) | 0.5381 |
| LightGBM + Optuna (**retenu**) | **0.5455** |

Lecture : en limitant la revue manuelle à 5% du volume total de dossiers, le modèle identifie environ **une fraude sur deux**. La métrique retenue est le recall à taux de faux positifs fixé, conformément au protocole d'évaluation standard de ce jeu de données — un F1 ou une précision au seuil 0.5 serait dégénéré sur un déséquilibre de classe à 1.1%.

Écart de performance entre entraînement et test : 0.0377 (surapprentissage contrôlé).

## Endpoints

| Méthode | Route | Description |
|---|---|---|
| `GET` | `/health` | État du service et seuil de décision actif |
| `POST` | `/predict` | Score une demande, retourne probabilité et décision |
| `GET` | `/docs` | Documentation interactive Swagger |

### Exemple

```bash
curl -X POST "https://<votre-space>.hf.space/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "income": 0.3, "customer_age": 40,
    "employment_status": "CB", "housing_status": "BA",
    "name_email_similarity": 0.42, "email_is_free": 1,
    "date_of_birth_distinct_emails_4w": 2,
    "phone_home_valid": 0, "phone_mobile_valid": 1, "foreign_request": 0,
    "prev_address_months_count": -1, "current_address_months_count": 24,
    "bank_months_count": 12, "bank_branch_count_8w": 5, "has_other_cards": 0,
    "credit_risk_score": 180, "proposed_credit_limit": 1500.0,
    "intended_balcon_amount": 12.5, "payment_type": "AB",
    "velocity_6h": 5200.0, "velocity_24h": 4800.0, "velocity_4w": 4900.0,
    "zip_count_4w": 1200, "days_since_request": 0.02,
    "source": "INTERNET", "device_os": "windows",
    "session_length_in_minutes": 6.5, "keep_alive_session": 1,
    "device_distinct_emails_8w": 1
  }'
```

Réponse :

```json
{
  "fraud_probability": 0.318442,
  "is_fraud_alert": false,
  "decision_threshold": 0.762091,
  "model_version": "1.0.0"
}
```

## Choix de conception

**L'API reçoit les champs bruts, pas les features transformées.** Tout le préprocessing (conversion des sentinelles `-1` en valeurs manquantes, flags de missingness, features dérivées, encodage one-hot) est reproduit côté serveur. Le client n'a aucune logique métier à implémenter, et il n'existe qu'une seule définition des features.

**Aucune imputation des valeurs manquantes.** Les `NaN` sont transmis tels quels au modèle : LightGBM apprend la direction de split optimale en leur présence, ce qui s'est révélé supérieur à une imputation par médiane. L'absence de donnée porte ici un vrai signal — un profil sans historique d'adresse précédente présente un taux de fraude 4.6× supérieur.

**Le vecteur de features est aligné par nom de colonne, pas reconstruit avec `get_dummies`.** Sur une ligne unique, `pd.get_dummies` produirait un vecteur au mauvais format que le modèle consommerait sans lever d'erreur, retournant une prédiction fausse en silence. L'ordre exact des colonnes est exporté avec le modèle et vérifié à chaque appel.

**Les modalités catégorielles inconnues sont rejetées (HTTP 422).** Sans ce contrôle, une valeur jamais vue à l'entraînement produirait un vecteur one-hot entièrement nul, interprété par le modèle comme la catégorie de référence.

**Les vélocités brutes sont exclues du modèle.** Elles présentent un drift temporel sévère (PSI de 0.92 à 2.89 entre les premiers et derniers mois). Elles restent demandées en entrée car nécessaires au calcul du ratio `velocity_24h / velocity_4w`, plus stable dans le temps.

## Limites

- Jeu de données synthétique : les modalités catégorielles sont anonymisées, sans dictionnaire de correspondance métier.
- Le plafond de performance reflète le signal disponible dans ces données publiques. Un système réel disposerait de sources supplémentaires (empreinte d'appareil, historique réseau, données inter-comptes).
- Aucune authentification sur cette démonstration : à ne pas déployer tel quel dans un contexte de production.

## Déploiement local

```bash
docker build -t fraud-api .
docker run -p 7860:7860 fraud-api
# http://localhost:7860/docs
```
