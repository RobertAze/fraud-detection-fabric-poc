"""Constantes figées au moment de l'entraînement.

Ces valeurs ne doivent JAMAIS diverger de celles utilisées dans `src/config.py`
côté Fabric. Si le modèle est réentraîné avec un périmètre de features différent,
il faut regénérer model_metadata.json ET vérifier ce fichier.
"""

from pathlib import Path

MODEL_DIR = Path(__file__).parent.parent / "model_export"
MODEL_PATH = MODEL_DIR / "lgbm_fraud_model.pkl"
METADATA_PATH = MODEL_DIR / "model_metadata.json"

# Colonnes catégorielles encodées en one-hot à l'entraînement.
CATEGORICAL_COLS = ["payment_type", "employment_status", "housing_status", "device_os", "source"]

# Modalités observées dans le jeu d'entraînement, relevées pendant l'exploration.
# Sert à REJETER une valeur inconnue plutôt qu'à la laisser passer silencieusement :
# sans ce garde-fou, une modalité jamais vue produirait un vecteur one-hot
# entièrement à zéro, que le modèle interpréterait comme la catégorie de référence
# (celle supprimée par drop_first) — une prédiction fausse, sans aucune erreur levée.
KNOWN_CATEGORIES = {
    "payment_type": ["AA", "AB", "AC", "AD", "AE"],
    "employment_status": ["CA", "CB", "CC", "CD", "CE", "CF", "CG"],
    "housing_status": ["BA", "BB", "BC", "BD", "BE", "BF", "BG"],
    "device_os": ["windows", "macintosh", "linux", "x11", "other"],
    "source": ["INTERNET", "TELEAPP"],
}

# Vélocités brutes exclues du modèle final (fort drift temporel, PSI > 0.9).
# Elles restent demandées en entrée car nécessaires au calcul du ratio.
DRIFTING_VELOCITY_COLS = ["velocity_6h", "velocity_24h", "velocity_4w"]

# Sentinelle de valeur manquante dans les données source.
MISSING_SENTINEL = -1
