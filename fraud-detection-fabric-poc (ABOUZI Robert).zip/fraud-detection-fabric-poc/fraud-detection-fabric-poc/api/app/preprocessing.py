"""Reproduction du préprocessing d'entraînement, pour une seule demande.

Point critique : on ne peut pas utiliser pd.get_dummies() ici. Sur une ligne unique,
il ne produirait qu'une seule colonne dummy par variable catégorielle, et donc un
vecteur de features au mauvais format et dans le mauvais ordre. Le modèle ne lèverait
pas nécessairement d'erreur — il lirait simplement les mauvaises valeurs aux mauvaises
positions et retournerait une prédiction fausse en silence.

La méthode retenue : construire un vecteur aligné sur `feature_columns` exporté à
l'entraînement, initialisé à zéro, puis remplir chaque position par son nom.
"""

import pandas as pd
import numpy as np

from app.config import CATEGORICAL_COLS, KNOWN_CATEGORIES, MISSING_SENTINEL


class UnknownCategoryError(ValueError):
    """Modalité catégorielle absente du jeu d'entraînement."""


def _normalize_missing(value):
    """La sentinelle -1 et null désignent la même chose : donnée absente.

    On les convertit en NaN, jamais en valeur imputée. LightGBM apprend lui-même
    la direction de split optimale en présence de NaN, ce qui s'est montré supérieur
    à une imputation par médiane sur ce jeu de données.
    """
    if value is None or value == MISSING_SENTINEL:
        return np.nan
    return value


def validate_categories(payload: dict) -> None:
    """Rejette toute modalité inconnue avant d'atteindre le modèle."""
    for col in CATEGORICAL_COLS:
        value = payload.get(col)
        if value not in KNOWN_CATEGORIES[col]:
            raise UnknownCategoryError(
                f"Valeur inconnue pour '{col}' : '{value}'. "
                f"Valeurs acceptées : {KNOWN_CATEGORIES[col]}"
            )


def build_feature_vector(payload: dict, feature_columns: list) -> pd.DataFrame:
    """Transforme une demande brute en vecteur de features aligné sur l'entraînement."""

    validate_categories(payload)

    # --- Étape Silver : sentinelles -> NaN, création des flags ---
    prev_address = payload.get("prev_address_months_count")
    current_address = _normalize_missing(payload.get("current_address_months_count"))

    features = {
        # Flags de missingness (signal de fraude mesuré, pas simple indicateur technique)
        "has_prev_address": 0 if (prev_address is None or prev_address == MISSING_SENTINEL) else 1,
        "current_address_missing": 1 if pd.isna(current_address) else 0,

        # Valeurs conservées en NaN natif, sans imputation
        "current_address_months_count": current_address,
        "bank_months_count": _normalize_missing(payload.get("bank_months_count")),
        "session_length_in_minutes": _normalize_missing(payload.get("session_length_in_minutes")),
        "device_distinct_emails_8w": _normalize_missing(payload.get("device_distinct_emails_8w")),

        # Colonnes numériques reprises telles quelles
        "income": payload["income"],
        "name_email_similarity": payload["name_email_similarity"],
        "customer_age": payload["customer_age"],
        "days_since_request": payload["days_since_request"],
        "intended_balcon_amount": payload["intended_balcon_amount"],
        "zip_count_4w": payload["zip_count_4w"],
        "bank_branch_count_8w": payload["bank_branch_count_8w"],
        "date_of_birth_distinct_emails_4w": payload["date_of_birth_distinct_emails_4w"],
        "credit_risk_score": payload["credit_risk_score"],
        "email_is_free": payload["email_is_free"],
        "phone_home_valid": payload["phone_home_valid"],
        "phone_mobile_valid": payload["phone_mobile_valid"],
        "has_other_cards": payload["has_other_cards"],
        "proposed_credit_limit": payload["proposed_credit_limit"],
        "foreign_request": payload["foreign_request"],
        "keep_alive_session": payload["keep_alive_session"],
    }

    # --- Étape Gold : features dérivées ---
    velocity_4w = payload["velocity_4w"]
    features["velocity_ratio_24h_4w"] = (
        payload["velocity_24h"] / velocity_4w if velocity_4w != 0 else np.nan
    )

    device_emails = features["device_distinct_emails_8w"]
    features["device_email_risk_score"] = (
        (1 if payload["email_is_free"] == 1 else 0)
        + (1 if (not pd.isna(device_emails) and device_emails > 1) else 0)
    )

    features["phone_validity_score"] = payload["phone_home_valid"] + payload["phone_mobile_valid"]

    # Les vélocités brutes ne sont volontairement pas ajoutées : exclues du modèle
    # final après un test d'ablation multi-seed (fort drift temporel).

    # --- One-hot figé : alignement strict sur les colonnes d'entraînement ---
    for col in CATEGORICAL_COLS:
        dummy_name = f"{col}_{payload[col]}"
        if dummy_name in feature_columns:
            features[dummy_name] = 1
        # Si absent de feature_columns, c'est la catégorie de référence supprimée
        # par drop_first=True : toutes ses dummies restent à 0, ce qui est correct.

    # Construction du vecteur final dans l'ordre exact de l'entraînement.
    vector = pd.DataFrame([{col: features.get(col, 0) for col in feature_columns}])

    # Garde-fou : toute divergence de schéma doit échouer bruyamment, pas silencieusement.
    assert list(vector.columns) == list(feature_columns), "Désalignement des colonnes de features"

    return vector
