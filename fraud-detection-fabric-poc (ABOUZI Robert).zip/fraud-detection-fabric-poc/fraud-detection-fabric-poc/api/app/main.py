"""API d'inférence temps réel — détection de fraude à l'ouverture de compte.

Complément du scoring batch exécuté côté Microsoft Fabric : même modèle, même
préprocessing, mais servi à la demande pour une décision unitaire.
"""

import json
import pickle
import logging

from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse

from app.config import MODEL_PATH, METADATA_PATH
from app.schemas import FraudRequest, FraudResponse, HealthResponse
from app.preprocessing import build_feature_vector, UnknownCategoryError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="API de détection de fraude — POC Ecobank",
    description=(
        "Score une demande d'ouverture de compte. Le seuil de décision est calibré "
        "à 5% de faux positifs : au-delà, la demande est signalée pour revue manuelle."
    ),
    version="1.0.0",
)

MODEL = None
METADATA = None


@app.on_event("startup")
def load_model():
    """Charge le modèle une seule fois au démarrage, pas à chaque requête."""
    global MODEL, METADATA

    if not MODEL_PATH.exists():
        logger.error(
            "Modèle introuvable : %s. Copier lgbm_fraud_model.pkl et model_metadata.json "
            "depuis Files/model_export/ du Lakehouse vers le dossier model_export/.",
            MODEL_PATH,
        )
        return

    with open(MODEL_PATH, "rb") as f:
        MODEL = pickle.load(f)
    with open(METADATA_PATH, "r") as f:
        METADATA = json.load(f)

    logger.info(
        "Modèle chargé : %d features, seuil de décision %.6f",
        len(METADATA["feature_columns"]),
        METADATA["decision_threshold"],
    )


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/docs")


@app.get("/health", response_model=HealthResponse)
def health():
    """Vérifie que le modèle est bien chargé et opérationnel."""
    if MODEL is None:
        raise HTTPException(status_code=503, detail="Modèle non chargé")
    return HealthResponse(
        status="ok",
        model_loaded=True,
        n_features=len(METADATA["feature_columns"]),
        decision_threshold=METADATA["decision_threshold"],
    )


@app.post("/predict", response_model=FraudResponse)
def predict(request: FraudRequest):
    """Score une demande et retourne la probabilité de fraude ainsi que la décision.

    La décision binaire applique le seuil calibré pendant l'évaluation (5% de faux
    positifs sur le jeu de test temporel), et non le seuil naïf de 0.5 — inadapté
    sur un problème avec 1.1% de fraude.
    """
    if MODEL is None:
        raise HTTPException(status_code=503, detail="Modèle non chargé")

    payload = request.model_dump()

    try:
        features = build_feature_vector(payload, METADATA["feature_columns"])
    except UnknownCategoryError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    probability = float(MODEL.predict_proba(features)[:, 1][0])
    threshold = METADATA["decision_threshold"]

    return FraudResponse(
        fraud_probability=round(probability, 6),
        is_fraud_alert=probability >= threshold,
        decision_threshold=threshold,
        model_version=app.version,
    )
