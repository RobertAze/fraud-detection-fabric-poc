"""Contrat d'entrée/sortie de l'API.

L'API reçoit les champs BRUTS d'une demande d'ouverture de compte — c'est-à-dire
ce qu'un système bancaire enverrait réellement au moment de la décision — et non
les features déjà transformées de la table Gold. Le préprocessing (Silver + Gold)
est reproduit côté API, garantissant que le client n'a aucune logique métier à
implémenter et qu'il n'existe qu'une seule définition des features.
"""

from typing import Optional
from pydantic import BaseModel, Field


class FraudRequest(BaseModel):
    """Une demande d'ouverture de compte à scorer.

    Les champs pouvant être absents dans le système source acceptent -1 (sentinelle
    d'origine) ou null. Les deux sont traités de façon identique.
    """

    # Profil demandeur
    income: float = Field(..., description="Revenu normalisé, bucketé par déciles (0.1 à 0.9)")
    customer_age: int = Field(..., description="Âge bucketé par décennie (10 à 90)")
    employment_status: str
    housing_status: str

    # Identité / cohérence
    name_email_similarity: float = Field(..., description="Similarité nom/email, entre 0 et 1")
    email_is_free: int = Field(..., ge=0, le=1)
    date_of_birth_distinct_emails_4w: int
    phone_home_valid: int = Field(..., ge=0, le=1)
    phone_mobile_valid: int = Field(..., ge=0, le=1)
    foreign_request: int = Field(..., ge=0, le=1)

    # Historique d'adresse (-1 ou null = absent ; signal de fraude confirmé)
    prev_address_months_count: Optional[int] = Field(
        None, description="-1 ou null si aucun historique d'adresse précédente"
    )
    current_address_months_count: Optional[int] = None

    # Relation bancaire
    bank_months_count: Optional[int] = Field(None, description="-1 ou null si non renseigné")
    bank_branch_count_8w: int
    has_other_cards: int = Field(..., ge=0, le=1)
    credit_risk_score: int
    proposed_credit_limit: float
    intended_balcon_amount: float
    payment_type: str

    # Activité (les vélocités brutes servent au calcul du ratio, puis sont écartées)
    velocity_6h: float
    velocity_24h: float
    velocity_4w: float
    zip_count_4w: int
    days_since_request: float

    # Session / appareil
    source: str
    device_os: str
    session_length_in_minutes: Optional[float] = None
    keep_alive_session: int = Field(..., ge=0, le=1)
    device_distinct_emails_8w: Optional[int] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "income": 0.3,
                "customer_age": 40,
                "employment_status": "CB",
                "housing_status": "BA",
                "name_email_similarity": 0.42,
                "email_is_free": 1,
                "date_of_birth_distinct_emails_4w": 2,
                "phone_home_valid": 0,
                "phone_mobile_valid": 1,
                "foreign_request": 0,
                "prev_address_months_count": -1,
                "current_address_months_count": 24,
                "bank_months_count": 12,
                "bank_branch_count_8w": 5,
                "has_other_cards": 0,
                "credit_risk_score": 180,
                "proposed_credit_limit": 1500.0,
                "intended_balcon_amount": 12.5,
                "payment_type": "AB",
                "velocity_6h": 5200.0,
                "velocity_24h": 4800.0,
                "velocity_4w": 4900.0,
                "zip_count_4w": 1200,
                "days_since_request": 0.02,
                "source": "INTERNET",
                "device_os": "windows",
                "session_length_in_minutes": 6.5,
                "keep_alive_session": 1,
                "device_distinct_emails_8w": 1,
            }
        }
    }


class FraudResponse(BaseModel):
    fraud_probability: float = Field(..., description="Score continu entre 0 et 1")
    is_fraud_alert: bool = Field(..., description="True si la probabilité dépasse le seuil de décision")
    decision_threshold: float = Field(..., description="Seuil calibré à 5% de faux positifs")
    model_version: str


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    n_features: int
    decision_threshold: float
