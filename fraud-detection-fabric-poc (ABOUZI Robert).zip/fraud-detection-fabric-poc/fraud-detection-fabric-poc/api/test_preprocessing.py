"""Tests du préprocessing, exécutables SANS le modèle entraîné.

Permet de valider la logique de transformation avant même d'avoir récupéré
le fichier .pkl depuis le Lakehouse.

    pytest test_preprocessing.py -v
"""

import numpy as np
import pytest

from app.preprocessing import build_feature_vector, validate_categories, UnknownCategoryError

# Extrait représentatif des colonnes produites à l'entraînement (ordre figé).
FEATURE_COLUMNS = [
    "income", "name_email_similarity", "current_address_months_count", "customer_age",
    "days_since_request", "intended_balcon_amount", "zip_count_4w", "bank_branch_count_8w",
    "date_of_birth_distinct_emails_4w", "credit_risk_score", "email_is_free",
    "phone_home_valid", "phone_mobile_valid", "bank_months_count", "has_other_cards",
    "proposed_credit_limit", "foreign_request", "session_length_in_minutes",
    "keep_alive_session", "device_distinct_emails_8w", "has_prev_address",
    "current_address_missing", "velocity_ratio_24h_4w", "device_email_risk_score",
    "phone_validity_score",
    # Dummies : la première modalité alphabétique est absente (drop_first=True)
    "payment_type_AB", "payment_type_AC", "payment_type_AD", "payment_type_AE",
    "employment_status_CB", "employment_status_CC", "employment_status_CD",
    "employment_status_CE", "employment_status_CF", "employment_status_CG",
    "housing_status_BB", "housing_status_BC", "housing_status_BD",
    "housing_status_BE", "housing_status_BF", "housing_status_BG",
    "device_os_macintosh", "device_os_other", "device_os_windows", "device_os_x11",
    "source_TELEAPP",
]

BASE_PAYLOAD = {
    "income": 0.3, "customer_age": 40,
    "employment_status": "CB", "housing_status": "BA",
    "name_email_similarity": 0.42, "email_is_free": 1,
    "date_of_birth_distinct_emails_4w": 2,
    "phone_home_valid": 0, "phone_mobile_valid": 1, "foreign_request": 0,
    "prev_address_months_count": -1, "current_address_months_count": 24,
    "bank_months_count": 12, "bank_branch_count_8w": 5, "has_other_cards": 0,
    "credit_risk_score": 180, "proposed_credit_limit": 1500.0,
    "intended_balcon_amount": 12.5, "payment_type": "AB",
    "velocity_6h": 5200.0, "velocity_24h": 4800.0, "velocity_4w": 4900.0,
    "zip_count_4w": 1200, "days_since_request": 0.02,
    "source": "INTERNET", "device_os": "windows",
    "session_length_in_minutes": 6.5, "keep_alive_session": 1,
    "device_distinct_emails_8w": 1,
}


def test_colonnes_alignees_sur_entrainement():
    vector = build_feature_vector(BASE_PAYLOAD, FEATURE_COLUMNS)
    assert list(vector.columns) == FEATURE_COLUMNS
    assert len(vector) == 1


def test_sentinelle_moins_un_devient_nan_pas_zero():
    """Une valeur -1 ne doit jamais être traitée comme un vrai zéro numérique."""
    payload = {**BASE_PAYLOAD, "bank_months_count": -1}
    vector = build_feature_vector(payload, FEATURE_COLUMNS)
    assert np.isnan(vector["bank_months_count"].iloc[0])


def test_flag_has_prev_address():
    absent = build_feature_vector({**BASE_PAYLOAD, "prev_address_months_count": -1}, FEATURE_COLUMNS)
    assert absent["has_prev_address"].iloc[0] == 0

    present = build_feature_vector({**BASE_PAYLOAD, "prev_address_months_count": 36}, FEATURE_COLUMNS)
    assert present["has_prev_address"].iloc[0] == 1

    via_null = build_feature_vector({**BASE_PAYLOAD, "prev_address_months_count": None}, FEATURE_COLUMNS)
    assert via_null["has_prev_address"].iloc[0] == 0


def test_ratio_velocite():
    vector = build_feature_vector(BASE_PAYLOAD, FEATURE_COLUMNS)
    attendu = 4800.0 / 4900.0
    assert vector["velocity_ratio_24h_4w"].iloc[0] == pytest.approx(attendu)


def test_division_par_zero_ne_plante_pas():
    payload = {**BASE_PAYLOAD, "velocity_4w": 0.0}
    vector = build_feature_vector(payload, FEATURE_COLUMNS)
    assert np.isnan(vector["velocity_ratio_24h_4w"].iloc[0])


def test_one_hot_correct():
    vector = build_feature_vector(BASE_PAYLOAD, FEATURE_COLUMNS)
    assert vector["payment_type_AB"].iloc[0] == 1
    assert vector["payment_type_AC"].iloc[0] == 0
    assert vector["device_os_windows"].iloc[0] == 1
    assert vector["device_os_macintosh"].iloc[0] == 0


def test_categorie_de_reference_toute_a_zero():
    """housing_status BA est la modalité supprimée par drop_first : toutes ses dummies à 0."""
    vector = build_feature_vector({**BASE_PAYLOAD, "housing_status": "BA"}, FEATURE_COLUMNS)
    dummies = [c for c in FEATURE_COLUMNS if c.startswith("housing_status_")]
    assert all(vector[c].iloc[0] == 0 for c in dummies)


def test_categorie_inconnue_rejetee():
    """Une modalité jamais vue doit lever une erreur, pas passer silencieusement."""
    with pytest.raises(UnknownCategoryError):
        validate_categories({**BASE_PAYLOAD, "device_os": "android"})


def test_scores_composites():
    vector = build_feature_vector(BASE_PAYLOAD, FEATURE_COLUMNS)
    # email_is_free=1 -> +1 ; device_distinct_emails_8w=1 (pas >1) -> +0
    assert vector["device_email_risk_score"].iloc[0] == 1
    # phone_home_valid=0 + phone_mobile_valid=1
    assert vector["phone_validity_score"].iloc[0] == 1


def test_velocites_brutes_absentes_du_vecteur():
    """Les vélocités brutes ne doivent pas atteindre le modèle (exclues par ablation)."""
    vector = build_feature_vector(BASE_PAYLOAD, FEATURE_COLUMNS)
    for col in ["velocity_6h", "velocity_24h", "velocity_4w"]:
        assert col not in vector.columns
