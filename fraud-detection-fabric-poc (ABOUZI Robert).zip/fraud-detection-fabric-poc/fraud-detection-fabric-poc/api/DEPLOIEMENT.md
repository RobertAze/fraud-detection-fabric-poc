# Guide de déploiement

## Prérequis bloquant

Le dossier `model_export/` est **vide**. Il doit contenir deux fichiers produits par le notebook `02_pipeline_entrainement.ipynb` côté Fabric :

- `lgbm_fraud_model.pkl`
- `model_metadata.json`

Tant que le notebook 02 n'a pas tourné, l'API démarre mais `/predict` répond **503**. Les tests du préprocessing (`pytest test_preprocessing.py`) fonctionnent en revanche dès maintenant, sans le modèle.

## 1. Récupérer le modèle depuis le Lakehouse

Dans Fabric : `Lakehouse > Files > model_export`, télécharger les deux fichiers, puis les placer dans `model_export/` de ce projet.

## 2. Vérifier la cohérence des catégories

Ouvrir `model_metadata.json` et comparer les noms de colonnes dummy avec `KNOWN_CATEGORIES` dans `app/config.py`. Si une modalité a été encodée différemment à l'entraînement, l'API rejettera à tort des requêtes valides.

Contrôle rapide en Python :

```python
import json
meta = json.load(open("model_export/model_metadata.json"))
print([c for c in meta["feature_columns"] if "_" in c and c.split("_")[0] in
       ("payment", "employment", "housing", "device", "source")])
```

## 3. Tester en local

```bash
pip install -r requirements.txt
pytest test_preprocessing.py -v
uvicorn app.main:app --reload --port 7860
```

Puis `http://localhost:7860/docs` — tester `/health` d'abord (doit répondre 200 avec `model_loaded: true`), ensuite `/predict` avec l'exemple pré-rempli.

## 4. Tester l'image Docker

```bash
docker build -t fraud-api .
docker run -p 7860:7860 fraud-api
```

Étape à ne pas sauter : une erreur de chemin ou de permission qui n'apparaît pas en local se manifestera ici, et déboguer localement est bien plus rapide que d'attendre un rebuild sur Hugging Face.

## 5. Déployer sur Hugging Face Spaces

1. Créer un compte sur huggingface.co, puis un Space : **New Space** → SDK **Docker** → Blank.
2. Cloner le dépôt du Space :
   ```bash
   git clone https://huggingface.co/spaces/<utilisateur>/<nom-du-space>
   ```
3. Copier tout le contenu de ce projet dedans, `model_export/` inclus.
4. Le `.pkl` peut dépasser 10 Mo — dans ce cas, activer Git LFS :
   ```bash
   git lfs install
   git lfs track "*.pkl"
   git add .gitattributes
   ```
5. Pousser :
   ```bash
   git add .
   git commit -m "API de détection de fraude"
   git push
   ```
6. Suivre l'onglet **Logs** du Space pendant le build. Une fois en ligne :
   `https://<utilisateur>-<nom-du-space>.hf.space/docs`

## Points de vigilance

**Le port doit être 7860** — cohérent entre `app_port` dans le frontmatter du README, `EXPOSE` et `CMD` dans le Dockerfile. Une incohérence produit un Space qui build correctement mais reste inaccessible.

**Le frontmatter YAML du README ne doit pas être supprimé** : sans lui, Hugging Face ne reconnaît pas la configuration du Space.

**Vérifier la version de LightGBM.** Un modèle sérialisé avec une version différente de celle installée dans le conteneur peut échouer au chargement, voire se charger avec un comportement modifié. Relever la version côté Fabric (`lightgbm.__version__`) et ajuster `requirements.txt` en conséquence.

**Aucune authentification.** Le Space est public : c'est acceptable pour une démonstration de portfolio, mais à mentionner explicitement comme limite.
