# Rapport de projet

Le rapport final sera déposé ici (`rapport_projet.pdf`).

Matériaux déjà prêts pour la rédaction :
- Plan de la section « Industrialisation & Perspectives » : ../docs/industrialisation_perspectives.md
- Tous les chiffres et justifications : ../presentations/scripts/fiche_technique_secours.pdf
- Analyse narrative complète : ../notebooks/04_presentation_projet.ipynb
