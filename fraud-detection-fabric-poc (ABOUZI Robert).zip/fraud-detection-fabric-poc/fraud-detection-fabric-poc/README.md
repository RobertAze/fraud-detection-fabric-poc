# Détection de fraude à l'ouverture de compte bancaire

**Pipeline complet sur Microsoft Fabric — architecture médaillon, LightGBM, MLflow, scoring batch et API temps réel.**

Preuve de concept construite de bout en bout sur le [Bank Account Fraud Suite](https://www.kaggle.com/datasets/sgpjesus/bank-account-fraud-dataset-neurips-2022) (Feedzai, NeurIPS 2022, variante Base) : 1 000 000 de demandes d'ouverture de compte, 1,10 % de fraude, 8 mois d'historique avec dérive temporelle volontaire.

---

## Résultats

| Modèle | Recall @ 5 % FPR |
|---|---|
| Régression logistique (référence) | 0,5066 |
| LightGBM, premier essai (non réglé) | 0,4885 |
| LightGBM, réglage manuel | 0,5381 |
| **LightGBM + Optuna (retenu)** | **0,5455** |

**Lecture métier :** en limitant la revue manuelle à 5 % du volume de dossiers, le modèle intercepte **54,6 % de la fraude** — environ 11 fois plus qu'un tri aléatoire, à charge de travail identique. Seuil de décision calibré : **0,762091** (FPR réel : 5,02 %). Écart apprentissage/test : 0,038 (surapprentissage contrôlé).

La métrique (recall à taux de faux positifs fixé) suit le protocole d'évaluation des auteurs du dataset — l'accuracy, la précision et le F1 au seuil 0,5 sont dégénérés sur un déséquilibre de classe à 1,1 %.

## Architecture

```
CSV source ──► BRONZE ──► SILVER ──► GOLD ──► Entraînement ──► model_export/
              (brut)    (nettoyé)  (features)  (LightGBM        (modèle + seuil
                                                + MLflow)        + colonnes)
                                        │                            │
                                        ▼                            ▼
                              ┌─── Scoring batch ───┐      ┌── API FastAPI ──┐
                              │ gold_scored_        │      │ Docker,         │
                              │ transactions        │      │ /predict        │
                              │  → Power BI         │      │ temps réel      │
                              │    (Direct Lake)    │      └─────────────────┘
                              └─────────────────────┘
```

Les trois notebooks du pipeline sont orchestrés par un **pipeline Data Factory** (`Pipeline_Orchestration_Fraud`) avec dépendances de succès : si une étape échoue, la suivante ne démarre pas. Chaque notebook appelle le package `src/` — les notebooks orchestrent, le package contient la logique.

## Ce qui distingue ce projet d'un tutoriel

Chaque décision découle d'une **mesure**, pas d'une pratique appliquée par habitude :

- **L'absence de donnée est un signal.** 71 % des dossiers n'ont pas d'historique d'adresse — et ces dossiers sont **4,6× plus souvent frauduleux**. L'imputation par médiane, engagée par réflexe, a été annulée après vérification : elle aurait détruit l'un des signaux les plus forts du dataset. Aucune imputation dans le pipeline final ; LightGBM exploite nativement les valeurs manquantes.
- **La dérive temporelle est mesurée, pas supposée.** PSI de 0,92 à 2,89 sur les variables de vélocité (seuil critique : 0,25), contre 0,02–0,07 sur les variables démographiques. Conséquences : split temporel (mois 0–5 / 6–7) au lieu d'aléatoire, et retrait des vélocités brutes au profit d'un ratio stable — gain validé sur 3 seeds.
- **Le leakage est audité.** `credit_risk_score` vérifié (corrélation 0,07 avec la cible : signal légitime, pas de fuite). L'early stopping utilisait initialement le jeu de test — corrigé par un troisième split de validation interne.
- **Les échecs sont documentés.** L'hypothèse « fenêtre d'entraînement récente > fenêtre complète » a été testée et **infirmée** (−0,012) : le volume d'exemples de fraude prime sur la fraîcheur. Deux flags de missingness créés se sont révélés inutilisés par le modèle (importance nulle) — redondants avec la gestion native des nulls.

Le détail complet : notebook [`04_presentation_projet`](notebooks/04_presentation_projet.ipynb) (66 cellules, analyse narrative) et [`presentations/scripts/fiche_technique_secours.pdf`](presentations/scripts/fiche_technique_secours.pdf).

## Structure du dépôt

```
├── notebooks/
│   ├── 01_pipeline_donnees.ipynb       Bronze → Silver → Gold + contrôles qualité
│   ├── 02_pipeline_entrainement.ipynb  Split temporel, LightGBM, MLflow, export
│   ├── 03_pipeline_scoring.ipynb       Scoring batch → table pour Power BI
│   └── 04_presentation_projet.ipynb    Analyse complète (EDA, drift, décisions, limites)
├── src/                                Package Python — toute la logique métier
│   ├── config.py                       Constantes validées empiriquement
│   ├── data/                           bronze.py, silver.py, gold.py
│   ├── models/                         train.py, tuning.py, evaluate.py, score.py
│   └── pipeline.py                     Orchestration bout-en-bout
├── tests/                              Tests de non-régression sur les hypothèses données
├── api/                                API FastAPI + Docker (inférence temps réel)
├── presentations/                      Supports (technique 15 min, management 10 min) + scripts PDF
├── docs/
│   ├── industrialisation_perspectives.md   Batch vs temps réel, architecture cible
│   └── captures/                       Captures Fabric (pipeline, MLflow, Power BI)
└── rapport/                            Rapport de projet
```

## Reproduire

**Sur Microsoft Fabric** (environnement d'origine) :
1. Créer un Lakehouse, uploader le CSV du dataset dans `Files/bronze_raw/` et le dossier `src/` dans `Files/` (*Upload folder*).
2. Importer les notebooks 01 → 02 → 03, attacher le Lakehouse à chacun, exécuter dans l'ordre — ou via le pipeline Data Factory.

**API en local :**
```bash
cd api
pip install -r requirements.txt
pytest test_preprocessing.py -v        # fonctionne sans le modèle
# placer lgm_fraud_model.pkl et model_metadata.json dans api/model_export/ (produits par le notebook 02)
uvicorn app.main:app --port 7860       # → http://localhost:7860/docs
```
Détails de déploiement (Docker, Hugging Face Spaces) : [`api/DEPLOIEMENT.md`](api/DEPLOIEMENT.md).

## Limites assumées

- **Dataset synthétique** (généré à partir de données réelles anonymisées) ; catégorielles codées sans dictionnaire métier.
- **Plafond de performance** lié au signal disponible : progresser passerait par des sources absentes d'un jeu public (empreinte d'appareil, signaux réseau, historique inter-comptes).
- **Pas de monitoring de dérive implémenté** — délibéré : sans flux de données vivant, il tournerait à vide. L'architecture cible est décrite dans [`docs/industrialisation_perspectives.md`](docs/industrialisation_perspectives.md).
- **API sans authentification** : démonstration, pas production.
- L'environnement Fabric d'origine était un essai à durée limitée ; tous les artefacts significatifs sont conservés dans ce dépôt.

## Stack

Microsoft Fabric (Lakehouse, notebooks PySpark, Data Factory, MLflow intégré) · LightGBM · Optuna · scikit-learn · FastAPI · Docker · Power BI (Direct Lake)

---

*Robert Abouzi — 2026*
