"""Tests de non-régression sur les hypothèses validées pendant l'exploration."""

from pyspark.sql import functions as F


def test_no_unexpected_nulls(spark):
    """Seules 4 colonnes doivent porter des nulls en Silver — et ils sont voulus."""
    df = spark.read.table("silver_transactions")
    expected = {'bank_months_count', 'current_address_months_count',
                'session_length_in_minutes', 'device_distinct_emails_8w'}
    null_counts = df.select(
        [F.count(F.when(F.col(c).isNull(), c)).alias(c) for c in df.columns]
    ).collect()[0].asDict()
    actual = {c for c, n in null_counts.items() if n > 0}
    assert actual == expected, f"Colonnes nulles inattendues : {actual ^ expected}"


def test_fraud_rate_in_expected_range(spark):
    """Le taux de fraude doit rester proche de 1.1% (variante Base)."""
    df = spark.read.table("bronze_transactions")
    rate = df.selectExpr("avg(fraud_bool) as r").collect()[0]['r']
    assert 0.005 < rate < 0.02, f"Taux de fraude hors plage : {rate}"


def test_no_constant_columns(spark):
    df = spark.read.table("silver_transactions")
    assert 'device_fraud_count' not in df.columns


def test_scored_table_alert_rate(spark):
    """Le taux d'alerte de la table scorée doit rester autour de 5% (seuil calibré).
    Une dérive forte signale un besoin de réétalonnage du seuil."""
    df = spark.read.table("gold_scored_transactions")
    alert_rate = df.selectExpr("avg(is_alert) as r").collect()[0]['r']
    assert 0.02 < alert_rate < 0.10, f"Taux d'alerte anormal : {alert_rate}"
