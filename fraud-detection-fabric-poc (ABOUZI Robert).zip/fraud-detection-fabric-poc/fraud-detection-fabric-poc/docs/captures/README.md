# Captures d'écran Fabric — à ajouter AVANT la fin de l'essai

L'environnement Fabric d'origine est un essai à durée limitée. Ces captures sont les
preuves d'exécution ; sans elles, le pipeline décrit n'est vérifiable par personne.

À déposer ici :

- [ ] `pipeline_data_factory.png` — Pipeline_Orchestration_Fraud avec ses **3 activités**
      (ajouter 03_pipeline_scoring comme 3e activité avant la capture) et un run réussi
- [ ] `mlflow_experience.png` — l'expérience fraud_detection_ecobank_poc, vue comparée
      des runs (baseline vs LightGBM vs Optuna)
- [ ] `mlflow_run_final.png` — le run lightgbm_optuna_final_with_threshold avec ses métriques
- [ ] `lakehouse_tables.png` — les 4 tables Delta (bronze, silver, gold, gold_scored)
- [ ] `table_scoree.png` — aperçu de gold_scored_transactions (colonnes fraud_score, is_alert)
- [ ] `powerbi_dashboard.png` — le tableau de bord connecté en Direct Lake
- [ ] `notebook_03_execute.png` — le notebook de scoring avec ses sorties (taux d'alerte ~5%)
