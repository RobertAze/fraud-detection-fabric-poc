# Industrialisation & Perspectives

Ce document a un double usage : il constitue le plan détaillé de la section « Industrialisation & Perspectives » du rapport final, et l'argumentaire à tenir devant un jury technique sur les choix d'architecture de déploiement.

---

## 1. Plan de la section pour le rapport

### 1.1 — Du modèle au système : ce qui a été industrialisé

À rédiger en s'appuyant sur l'existant du dépôt, dans cet ordre :

1. **Modularisation** — la logique métier vit dans un package (`src/`), pas dans des cellules de notebook. Les notebooks orchestrent, le package exécute. Argument : testabilité, réutilisabilité sur un autre jeu de données, revue de code possible.
2. **Orchestration** — pipeline Data Factory à trois activités (données → entraînement → scoring) avec dépendances de succès. Argument : rejouabilité, échec explicite plutôt que continuation silencieuse.
3. **Contrôles qualité automatisés** — les hypothèses validées pendant l'exploration (colonnes nulles attendues, plage du taux de fraude, taux d'alerte du scoring) sont des assertions qui font échouer le pipeline si elles cassent. Argument : les hypothèses sur les données sont du code, pas de la documentation.
4. **Traçabilité** — chaque entraînement est un run MLflow (paramètres, métriques, modèle). Argument : la progression 0,5066 → 0,5455 est prouvable, pas reconstituée de mémoire.
5. **Contrat de déploiement** — `model_export/` regroupe le modèle, le seuil calibré et l'ordre exact des colonnes. Argument : un modèle livré sans son seuil et son schéma de features est inutilisable ; les trois voyagent ensemble.

### 1.2 — Les deux voies de mise à disposition (voir §2 ci-dessous)

### 1.3 — Ce qu'il resterait à construire pour une vraie production

À présenter comme architecture cible, en étant explicite sur le fait qu'elle n'est **pas implémentée** — et pourquoi (dataset figé, pas de flux vivant) :

| Dispositif | Rôle | Déclencheur |
|---|---|---|
| Surveillance de dérive (PSI périodique) | Détecter que les données entrantes s'éloignent de l'entraînement | PSI > 0,25 sur une variable clé → alerte |
| Contrôle du volume d'alertes | Détecter un seuil désétalonné | Taux d'alerte hors de [3 %, 8 %] → réétalonnage |
| Réentraînement sur fenêtre glissante | Absorber la dérive | Périodique (mensuel/trimestriel), avec comparaison au modèle en place avant remplacement — jamais de remplacement aveugle |
| Model Registry avec stages | Gérer les versions (staging/production) proprement | Remplace le dossier `model_export/` artisanal |
| Authentification et journalisation de l'API | Prérequis réglementaire bancaire | Avant toute exposition réelle |
| Revue de conformité des variables | Ex. : `device_os` (signal fort mais sensible) | Avant mise en production |

Point d'honnêteté à garder dans le rapport : le POC a *mesuré* la dérive (PSI jusqu'à 2,89) et en a tiré des décisions de modélisation, mais ne la *surveille* pas en continu — la distinction entre les deux est précisément ce qu'un jury attend qu'on sache faire.

### 1.4 — Enseignements transposables au contexte Ecobank

1. La logique médaillon et l'outillage (Fabric, Data Factory, Power BI) sont ceux du groupe — transfert direct.
2. La méthode d'audit (sentinelles, signal de missingness, PSI, leakage) est indépendante du dataset.
3. Les prérequis identifiés pour un cas réel : historique de cas confirmés (plusieurs milliers), données accessibles, et un consommateur métier identifié pour les alertes.

---

## 2. Batch vs temps réel : l'argumentaire complet

**Le point central à défendre : ce n'est pas un choix entre deux options, ce sont deux réponses à deux questions métier différentes.** Les présenter comme concurrentes serait une erreur d'analyse ; le dispositif complet a besoin des deux.

### 2.1 — Voie batch : scoring par lots sur Fabric + Power BI

**La question métier servie :** *« Sur quoi mon équipe d'analystes doit-elle passer sa journée ? »* — pilotage d'une capacité de contrôle limitée.

| Dimension | Argument |
|---|---|
| **Métier** | Les analystes travaillent par file de priorité, pas par dossier isolé. Un tableau de bord trié par score épouse leur organisation réelle. |
| **Métier** | Le pilotage exige des agrégats : volume d'alertes vs capacité, précision des alertes a posteriori, évolution mensuelle — c'est de la restitution BI, pas de l'API. |
| **Technique** | Le scoring d'un million de lignes en une passe est trivial et économique en batch ; en appels unitaires il serait absurde. |
| **Technique** | Direct Lake lit la table Delta sans duplication ni rafraîchissement planifié — la table scorée écrite par le notebook 03 est immédiatement visible dans Power BI. |
| **Technique** | La colonne `scored_at` + `model_threshold` dans la table donne l'auditabilité : on sait quelle version a scoré quelle ligne. |
| **Limite à admettre** | Latence structurelle : un dossier arrivé après le dernier run n'est pas scoré. Acceptable pour la revue et le pilotage, insuffisant pour agir *pendant* la demande. |

### 2.2 — Voie temps réel : API FastAPI conteneurisée

**La question métier servie :** *« Que fait-on de CETTE demande, maintenant, pendant que le client est encore sur le formulaire ? »* — action dans le parcours d'ouverture.

| Dimension | Argument |
|---|---|
| **Métier** | La fraude à l'ouverture se joue au moment de la demande : déclencher une vérification renforcée (pièce supplémentaire, validation différée) pendant le parcours a bien plus de valeur que de constater la fraude au batch du lendemain, compte déjà ouvert. |
| **Métier** | La réponse est graduée, pas binaire : le score permet un parcours différencié (fluide / vérification légère / revue manuelle) au lieu d'un refus brutal. |
| **Technique** | L'API reçoit les **champs bruts** et reproduit tout le préprocessing côté serveur : le système appelant n'implémente aucune logique métier, et il n'existe qu'une seule définition des features — zéro risque de divergence entraînement/production (*training-serving skew*). |
| **Technique** | Le vecteur d'inférence est aligné **par nom de colonne** sur le contrat d'entraînement, jamais reconstruit par `get_dummies` sur une ligne isolée — ce qui produirait des scores silencieusement faux. Les modalités inconnues sont rejetées (HTTP 422) au lieu d'être avalées comme catégorie de référence. |
| **Technique** | Conteneurisation Docker : même image en local, en démo (Hugging Face Spaces) et, demain, sur n'importe quel orchestrateur du groupe. Le modèle et son seuil sont embarqués ensemble. |
| **Limite à admettre** | Pas d'authentification ni de journalisation dans le POC ; en contexte bancaire, ce sont des prérequis réglementaires avant toute exposition. |

### 2.3 — La synthèse à énoncer devant le jury

> « Le batch répond à *comment j'organise ma capacité de contrôle*, le temps réel à *comment j'agis sur ce dossier pendant qu'il se présente*. Le même modèle, le même seuil et le même préprocessing servent les deux — c'est le contrat `model_export/` qui garantit cette cohérence. Un dispositif anti-fraude mature a besoin des deux voies ; n'en présenter qu'une, c'est ne traiter que la moitié du problème. »

### 2.4 — Questions pièges probables du jury, et réponses

- **« Pourquoi pas tout en temps réel ? »** — Coût et besoin : scorer un million de lignes historiques par appels unitaires n'a aucun sens, et le pilotage des analystes est un besoin d'agrégats, pas de latence.
- **« Pourquoi pas tout en batch ? »** — Parce que la fraude à l'ouverture se joue pendant la demande ; au batch du lendemain, le compte est ouvert.
- **« Comment garantissez-vous que l'API score comme l'entraînement ? »** — Contrat unique (modèle + seuil + ordre des colonnes), alignement par nom, rejet des modalités inconnues, et tests automatisés du préprocessing exécutables sans le modèle.
- **« Que se passe-t-il quand le modèle vieillit ? »** — Le taux d'alerte du batch est le premier détecteur (calibré à ~5 %, toute dérive forte déclenche le contrôle qualité) ; l'architecture cible ajoute le PSI périodique et le réentraînement comparé sur fenêtre glissante.

---

## 3. Évolution de l'arborescence (réalisée dans ce dépôt)

L'intégration de la phase d'inférence a modifié la structure ainsi :

```
notebooks/03_pipeline_scoring.ipynb   ← nouveau : 3e activité du pipeline Data Factory
notebooks/04_presentation_projet.ipynb ← renuméroté (ex-03) : la présentation n'est pas
                                          une étape du pipeline, elle vient après
src/models/score.py                    ← nouveau : logique de scoring batch réutilisable
                                          (chargement du contrat, alignement, écriture)
src/pipeline.py                        ← étendu : run_full_pipeline inclut le scoring
tests/test_data_quality.py             ← étendu : contrôle du taux d'alerte de la table scorée
```

Principe conservé : **le notebook orchestre, le package exécute.** Le notebook 03 ne contient aucune logique qui ne soit pas dans `src/models/score.py` — il l'appelle, vérifie, et documente.
